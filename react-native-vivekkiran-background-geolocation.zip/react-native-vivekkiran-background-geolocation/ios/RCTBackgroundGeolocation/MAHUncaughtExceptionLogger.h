//
//  MAHUncaughtExceptionLogger.h
//  RCTBackgroundGeolocation
//
//  Created by Marian Hello on 12/04/2018.
//  Copyright © 2018 mauron85. All rights reserved.
//

#ifndef MAHUncaughtExceptionLogger_h
#define MAHUncaughtExceptionLogger_h

// reexport
#import "BackgroundGeolocation/UncaughtExceptionLogger.h"

#endif /* MAHUncaughtExceptionLogger_h */
