package com.marianhello.bgloc.data;

import com.marianhello.bgloc.data.LocationTemplate;

import java.io.Serializable;

/**
 * Created by finch on 9.12.2017.
 */

abstract public class AbstractLocationTemplate implements LocationTemplate, Serializable {
    public static final String BUNDLE_KEY = "template";
}
